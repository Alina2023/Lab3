﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace ConsoleApp
{
    class Program
    {
        static TcpListener server;
        static List<StreamWriter> connectedClients = new List<StreamWriter>();

        static void Main(string[] args)
        {
            int port = 12345; // Укажите здесь порт, на котором сервер будет слушать подключения

            try
            {
                server = new TcpListener(IPAddress.Any, port);
                server.Start();

                Console.WriteLine($"Сервер запущен. Ожидание подключений на порту {port}...");

                while (true)
                {
                    TcpClient client = server.AcceptTcpClient();
                    Thread clientThread = new Thread(() => HandleClient(client));
                    clientThread.Start();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка сервера: {ex.Message}");
            }
            finally
            {
                server.Stop();
            }
        }

        static void HandleClient(TcpClient client)
        {
            StreamWriter writer = new StreamWriter(client.GetStream(), Encoding.UTF8) { AutoFlush = true };

            try
            {
                connectedClients.Add(writer);

                StreamReader reader = new StreamReader(client.GetStream(), Encoding.UTF8);
                string username = reader.ReadLine();
                Console.WriteLine($"{username} присоединился к чату.");

                while (true)
                {
                    string message = reader.ReadLine();
                    if (message == null)
                    {
                        break;
                    }

                    if (message.StartsWith("All: "))
                    {
                        string messageToSend = $"{username}: {message.Substring(5)}";
                        Console.WriteLine(messageToSend);
                        foreach (var clientWriter in connectedClients)
                        {
                            clientWriter.WriteLine(messageToSend);
                        }
                    }
                    else
                    {
                        Console.WriteLine($"{username} (приватно): {message}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка обработки клиента: {ex.Message}");
            }
            finally
            {
                connectedClients.Remove(writer);
                client.Close();
                Console.WriteLine($"{writer} покинул чат.");
            }
        }
    }
}




