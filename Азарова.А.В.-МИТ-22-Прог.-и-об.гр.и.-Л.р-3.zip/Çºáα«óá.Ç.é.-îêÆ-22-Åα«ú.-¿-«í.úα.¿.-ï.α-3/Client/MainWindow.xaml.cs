﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
public partial class MainWindow : Window
{
    private TcpClient client;
    private StreamReader reader;
    private StreamWriter writer;
}
namespace Lab3
{
    public partial class MainWindow : Window
    {
        private TcpClient client;
        private StreamReader reader;
        private StreamWriter writer;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            string serverIp = ServerIpTextBox.Text;
            int serverPort = int.Parse(ServerPortTextBox.Text);
            string username = UsernameTextBox.Text;

            try
            {
                client = new TcpClient(serverIp, serverPort);
                NetworkStream stream = client.GetStream();
                reader = new StreamReader(stream, Encoding.UTF8);
                writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };

                writer.WriteLine(username);
                ConnectButton.IsEnabled = false;
                SendButton.IsEnabled = true;

                // Start a background thread to listen for incoming messages
                var messageListener = new System.Threading.Thread(() =>
                {
                    while (true)
                    {
                        try
                        {
                            string message = reader.ReadLine();
                            Dispatcher.Invoke(() => AddMessageToChat(message));
                        }
                        catch (IOException)
                        {
                            MessageBox.Show("Соединение было разорвано.");
                            break;
                        }
                    }
                });
                messageListener.IsBackground = true;
                messageListener.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения: " + ex.Message);
            }
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string message = MessageTextBox.Text;

            if (SendToAllCheckBox.IsChecked == true)
            {
                // Отправка сообщения всем адресатам
                writer.WriteLine("All: " + message);
            }
            else
            {
                // Отправка сообщения выбранному адресату
                writer.WriteLine(message);
            }

            MessageTextBox.Clear();
        }

        private void AddMessageToChat(string message)
        {
            ChatTextBox.AppendText(message + Environment.NewLine);
        }
        private void DisconnectButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Закрываем соединение с сервером
                if (client != null)
                {
                    client.Close();
                    client = null;
                }

                // Закрываем читателя и писателя
                if (reader != null)
                    reader.Close();
                if (writer != null)
                    writer.Close();

                ConnectButton.IsEnabled = true;
                SendButton.IsEnabled = false;
                DisconnectButton.IsEnabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка отключения: " + ex.Message);
            }
        }

    }
}